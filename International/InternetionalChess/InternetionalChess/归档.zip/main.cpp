//
//  main.cpp
//  InternetionalChess
//
//  Created by 姚晨 on 2025/11/11.
//

#include <iostream>
#include "display.h"
using namespace std;
int main(int argc, const char * argv[]) {
    cout << "下面是国际象棋的棋盘展示程序" <<endl;
    displayChess();
}
