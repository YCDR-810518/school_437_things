//
//  search.h
//  InternetionalChess
//
//  Created by 姚晨 on 2025/11/18.
//
#ifndef _SEARCH_H_
#define _SEARCH_H_
#include <iostream>
#include <vector>
#include <string>
using namespace std;

// 查询各个位置的情况
string searchChessBox(char length, int vertical);
string searchColor(char length, int vertical);
void transferPoint(char stalength, int *stavertical,
                   char endlength, int *endvertical);

#endif
