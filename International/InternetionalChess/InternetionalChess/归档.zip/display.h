//
//  display.h
//  InternetionalChess
//
//  Created by 姚晨 on 2025/11/11.
//
#ifndef _DISPLAY_H_
#define _DISPLAY_H_
#include <iostream>
void displayChess();
#endif
