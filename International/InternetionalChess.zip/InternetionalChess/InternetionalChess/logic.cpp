#include "logic.h"
#include "search.h"
#include <iostream>
#include <vector>
#include <string>
#include <cmath>  // 添加cmath头文件用于abs()函数
using namespace std;

extern int chessColorMap[8][8];
extern vector<vector<string>> chessMap;

// 路径上障碍逻辑判断
int logic_PathCheck(char stalength, int stavertical, char endlength, int endvertical) {
    // 转换为数组索引
    int startRow = 8 - stavertical;
    int startCol = stalength - 'a';
    int endRow = 8 - endvertical;
    int endCol = endlength - 'a';
    
    // 检查是否在同一行
    if (startRow == endRow) {
        int step = (endCol > startCol) ? 1 : -1;
        for (int col = startCol + step; col != endCol; col += step) {
            if (!chessMap[startRow][col].empty()) {
                return 0; // 路径上有障碍物
            }
        }
    }
    // 检查是否在同一列
    else if (startCol == endCol) {
        int step = (endRow > startRow) ? 1 : -1;
        for (int row = startRow + step; row != endRow; row += step) {
            if (!chessMap[row][startCol].empty()) {
                return 0; // 路径上有障碍物
            }
        }
    }
    // 检查是否在同一斜线
    else if (abs(endRow - startRow) == abs(endCol - startCol)) {
        int rowStep = (endRow > startRow) ? 1 : -1;
        int colStep = (endCol > startCol) ? 1 : -1;
        int row = startRow + rowStep;
        int col = startCol + colStep;
        
        while (row != endRow && col != endCol) {
            if (!chessMap[row][col].empty()) {
                return 0; // 路径上有障碍物
            }
            row += rowStep;
            col += colStep;
        }
    }
    
    return 1; // 路径畅通
}

//起落点的逻辑判断
int logic_PointCheck(char stalength, int stavertical,
                     char endlength, int endvertical){
    int logic_choice;
    
    // 基础检查 - 修复了水平方向检查逻辑
    if(stavertical > 8 || endvertical > 8) {
        cout << "你在竖直方向超越了棋盘";
        return 0;
    }
    else if (stavertical <= 0 || endvertical <= 0) {
        cout << "棋盘上莫得负数，沙锅";
        return 0;
    }
    // 修复：水平方向检查条件写反了
    else if (stalength < 'a' || stalength > 'h' || endlength < 'a' || endlength > 'h') {
        cout << "你在水平方向超越了棋盘";
        return 0;
    }
    else if (searchChessBox(stalength,stavertical).empty()) {
        cout << "起始点象棋不存在";
        return 0;
    }
    
    // 获取棋子类型
    string piece = searchChessBox(stalength,stavertical);
    
    if (piece == "pawn" || piece == "Pawn") {
        logic_choice =1;
    }else if (piece == "rook" || piece == "Rook") {
        logic_choice =2;
    }else if (piece == "knight" || piece == "Knight") {
        logic_choice =3;
    }else if (piece == "bishop" || piece == "Bishop") {
        logic_choice =4;
    }else if (piece == "queen" || piece == "Queen") {
        logic_choice =5;
    }else if (piece == "king" || piece == "King") {
        logic_choice =6;
    }else{
        cout << "logic_PointCheck函数中的前半段判断存在未知错误" << endl;
        return 0;
    }
    
    // 转换为数组索引用于计算
    int startRow = 8 - stavertical;
    int startCol = stalength - 'a';
    int endRow = 8 - endvertical;
    int endCol = endlength - 'a';
    int rowDiff = abs(endRow - startRow);
    int colDiff = abs(endCol - startCol);
    
    switch (logic_choice) {
        case 1: // 兵(Pawn)的逻辑
        {
            string color = searchColor(stalength, stavertical);
            int direction = (color == "Black") ? 1 : -1; // 黑方向下，白方向上
            
            // 基本前进
            if (startCol == endCol) {
                // 前进一格
                if (endRow == startRow + direction && searchChessBox(endlength, endvertical).empty()) {
                    return 1;
                }
                // 起始位置前进两格
                else if ((color == "Black" && startRow == 1) || (color == "White" && startRow == 6)) {
                    if (endRow == startRow + 2 * direction &&
                        searchChessBox(endlength, endvertical).empty() &&
                        logic_PathCheck(stalength, stavertical, endlength, endvertical)) {
                        return 1;
                    }
                }
            }
            // 吃子（斜向前进）
            else if (colDiff == 1 && rowDiff == 1 && endRow == startRow + direction) {
                if (!searchChessBox(endlength, endvertical).empty() &&
                    searchColor(endlength, endvertical) != color) {
                    return 1;
                }
            }
            break;
        }
            
        case 2: // 车(Rook)的逻辑
        {
            // 车只能横向或纵向移动
            if ((startRow == endRow || startCol == endCol) &&
                logic_PathCheck(stalength, stavertical, endlength, endvertical)) {
                // 检查目标位置是否有己方棋子
                if (searchChessBox(endlength, endvertical).empty() ||
                    searchColor(endlength, endvertical) != searchColor(stalength, stavertical)) {
                    return 1;
                }
            }
            break;
        }
            
        case 3: // 马(Knight)的逻辑
        {
            // 马走日字 (L形移动)
            if ((rowDiff == 2 && colDiff == 1) || (rowDiff == 1 && colDiff == 2)) {
                // 马可以跳过其他棋子，只检查目标位置
                if (searchChessBox(endlength, endvertical).empty() ||
                    searchColor(endlength, endvertical) != searchColor(stalength, stavertical)) {
                    return 1;
                }
            }
            break;
        }
            
        case 4: // 象(Bishop)的逻辑
        {
            // 象只能斜向移动
            if (rowDiff == colDiff &&
                logic_PathCheck(stalength, stavertical, endlength, endvertical)) {
                if (searchChessBox(endlength, endvertical).empty() ||
                    searchColor(endlength, endvertical) != searchColor(stalength, stavertical)) {
                    return 1;
                }
            }
            break;
        }
            
        case 5: // 后(Queen)的逻辑
        {
            // 后可以横向、纵向或斜向移动
            if ((startRow == endRow || startCol == endCol || rowDiff == colDiff) &&
                logic_PathCheck(stalength, stavertical, endlength, endvertical)) {
                if (searchChessBox(endlength, endvertical).empty() ||
                    searchColor(endlength, endvertical) != searchColor(stalength, stavertical)) {
                    return 1;
                }
            }
            break;
        }
            
        case 6: // 王(King)的逻辑
        {
            // 王可以移动一格（任何方向）
            if (rowDiff <= 1 && colDiff <= 1) {
                if (searchChessBox(endlength, endvertical).empty() ||
                    searchColor(endlength, endvertical) != searchColor(stalength, stavertical)) {
                    return 1;
                }
            }
            break;
        }
            
        default:
            cout << "CHESS ACTION LOGIC ERROR!" << endl;
            return 0;
    }
    
    return 0;
}

// 移动棋子函数
bool moveChess(char stalength, int stavertical, char endlength, int endvertical) {
    // 首先检查移动是否合法
    if (logic_PointCheck(stalength, stavertical, endlength, endvertical) == 0) {
        cout << "移动不合法！" << endl;
        return false;
    }
    
    // 转换为数组索引
    int startRow = 8 - stavertical;
    int startCol = stalength - 'a';
    int endRow = 8 - endvertical;
    int endCol = endlength - 'a';
    
    // 保存移动前的棋子信息（用于显示）
    string movedPiece = chessMap[startRow][startCol];
    int movedPieceColor = chessColorMap[startRow][startCol];
    
    // 执行移动 - 更新棋盘数组
    chessMap[endRow][endCol] = chessMap[startRow][startCol];
    chessMap[startRow][startCol] = "";
    
    // 执行移动 - 更新颜色映射数组
    chessColorMap[endRow][endCol] = chessColorMap[startRow][startCol];
    chessColorMap[startRow][startCol] = 0; // 0 表示空白
    
    // 显示移动信息
    cout << "移动: " << stalength << stavertical << " -> " << endlength << endvertical << endl;
    cout << "移动棋子: " << movedPiece << " ("
         << (movedPieceColor == -1 ? "白方" : movedPieceColor == 1 ? "黑方" : "未知") << ")" << endl;
    
    cout << "移动成功！" << endl;
    
    return true;
}
